export class Role {
    public static Admin = "Admin";
    public static Member = "Member";
}

export enum Roles {
    Admin = 1,
    Member = 2
}