export interface UserInfo {
    Id: number;
    UserName: string;
    Role: string;
}