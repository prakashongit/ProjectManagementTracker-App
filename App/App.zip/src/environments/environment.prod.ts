export const environment = {
  production: true,
  apiURL: 'https://localhost:44321/projectmgmt/api/v1/'
};
